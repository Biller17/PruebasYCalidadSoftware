
import resources.ScriptRecorderHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author IEUser
 */
public class ScriptRecorder extends ScriptRecorderHelper
{
	/**
	 * Script Name   : <b>ScriptRecorder</b>
	 * Generated     : <b>Mar 17, 2017 11:45:10 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 10.0  Build 14393 ()
	 * 
	 * @since  2017/03/17
	 * @author IEUser
	 */
	public void testMain(Object[] args) 
	{
		
		// Frame: JmeterTarea.jmx (C:\Users\IEUser\Desktop\JmeterTarea.jmx) - Apache JMeter (3.1 r1770033)
		mainFrame4().click(atPath("Plan de Pruebas->Grupo de Hilos->Valores por Defecto para Petici�n HTTP"));
		// TabbedPage
		serverNameOrIP().doubleClick(atPoint(25,7));
		jmeterTareaJmxCUsersIEUserDesk().inputChars(dpString("Hostnames"));
		start().click();
		_stop().click();
		mainFrame4().click(atPath("Plan de Pruebas->Grupo de Hilos->View Results Tree"));
		clear().click();
	}
}

